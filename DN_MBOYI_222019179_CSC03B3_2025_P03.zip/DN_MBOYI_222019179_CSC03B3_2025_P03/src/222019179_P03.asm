;	Update all of this information to reflect your own details and the prac
;	Author:     DN MBOYI 222019179 P03
;	Template document
.386
.MODEL FLAT ; Flat memory model
.STACK 4096 ; 4096 bytes

; Exit function
ExitProcess PROTO NEAR32 stdcall, dwExitCode:DWORD
INCLUDE io.inc
; The data section stores all global variables
.DATA
;The only needed global variables:
intRequiredAmount DWORD ?
intOutputPerMin DWORD ?
intInputPerMin DWORD 5 DUP(?); this is an array of integers
intRequiredInput DWORD 5 DUP(?) ; Array of 5 elements for outputs

;The strings we shall utilize:
strRequiredAmount BYTE "Please enter the RequiredAmount ",0
strOutputPerMin BYTE "Please enter the OutputPerMin ",0
strInputPerMin BYTE "Please enter the InputPerMin ",0
strNumberOfLines BYTE "The number of lines calculated is ",0
strInput BYTE "The number of inputs are ",0
strRequiredInput BYTE "This is the required total input based on the number of lines ",0
strNewLine BYTE 10,0
strLeftBracket BYTE 91,0 ;This is the left bracket
strRightBracket BYTE 93,0 ;This is te right bracket
strComma BYTE 44,0
strColon BYTE 58,0
strExit BYTE "Do you want to continue?( 1=Yes, 0=No )",0


; The code section may contain multiple tags such as _start, which is the entry
; point of this assembly program
.CODE
_start:

startProcess:

;Prompt the user for the RequiredAmount value
INVOKE OutputStr, ADDR strRequiredAmount
INVOKE InputInt 
MOV intRequiredAmount, eax

;Prompt the user for the OuputPerMin value
INVOKE OutputStr, ADDR strOutputPerMin
INVOKE InputInt
MOV intOutputPerMin, eax

; Get input per minute array
MOV ecx, 0                  
LEA ebx, intInputPerMin 

startInputLoop:
            CMP ecx, 5
            JGE endInputLoop
            
            ; Prompt for current element
            INVOKE OutputStr, ADDR strInputPerMin
            MOV eax, ecx
            INC eax                  
            INVOKE OutputInt, eax
            INVOKE OutputStr, ADDR strColon
            INVOKE InputInt
            
            ; Store the input in an array
            MOV [ebx], eax
            ADD ebx, 4            
            INC ecx                 
            JMP startInputLoop
            
        endInputLoop:

 ; Display input values
        INVOKE OutputStr, ADDR strInput
        INVOKE OutputStr, ADDR strLeftBracket
        LEA ebx, intInputPerMin
        MOV ecx, 0
        
intDisplayLoop:
    CMP ecx, 5
    JGE intEndDisplayLoop
    INVOKE OutputInt, [ebx]
    ADD ebx, 4
    INC ecx
    CMP ecx, 5
    JGE skipComma
    INVOKE OutputStr, ADDR strComma

    skipComma:
    JMP intDisplayLoop
            
intEndDisplayLoop:

    INVOKE OutputStr, ADDR strRightBracket
    INVOKE OutputStr, ADDR strNewLine

; Calculate number of production lines 
    MOV eax, intRequiredAmount
    XOR edx, edx                
    DIV intOutputPerMin            
                                    
        
; Check if we need to round up 
    CMP edx, 0
    JE noRoundUp
    INC eax                     
    noRoundUp:
        
; eax now contains numberOfWholeLines
    MOV edx, eax               
        
; Display number of production lines
    INVOKE OutputStr, ADDR strNumberOfLines
    INVOKE OutputInt, edx
    INVOKE OutputStr, ADDR strNewLine


; Calculate required input
    LEA ebx, intInputPerMin        
    LEA ecx, intRequiredInput      
    MOV eax, 0                  
        
RequiredLoop:
    CMP eax, 5
    JGE endRequiredLoop
            
    PUSH eax                
    MOV eax, [ebx]         
    MUL edx          
    MOV [ecx], edx          
            
    ADD ebx, 4
    ADD ecx, 4
    INC eax
    POP eax                 
    JMP RequiredLoop
            
 endRequiredLoop:

 ; Display the required input
INVOKE OutputStr, ADDR strRequiredInput
INVOKE OutputStr, ADDR strLeftBracket


LEA ebx, intRequiredInput
MOV ecx, 0
        
DisplayOutputLoop:
    CMP ecx, 5
    JGE endDisplayOutputLoop
    INVOKE OutputInt, [ebx]
    ADD ebx, 4
    INC ecx
    CMP ecx, 5
    JGE skipCommaOutput
    INVOKE OutputStr, ADDR strComma

    skipCommaOutput:
    JMP displayOutputLoop
            
endDisplayOutputLoop:
    INVOKE OutputStr, ADDR strRightBracket
    INVOKE OutputStr, ADDR strNewLine

; Continue prompt
    INVOKE OutputStr, ADDR strExit
    INVOKE InputInt 
    CMP eax, 1
    JE startProcess



endProcess:
; Most of your initial code will be under the _start tag.
	; The _start tag is just a memory address referenced by the Public indicator
	; highlighting which functions are available to calling functions.
	; _start gets called by the operating system to start this process.


;Prompt the user for the InputPerMin value
INVOKE OutputStr, ADDR strInputPerMin
INVOKE InputInt
MOV intInputPerMin, eax

	
 

	; We call the Operating System ExitProcess system call to close the process.
	INVOKE ExitProcess, 0
Public _start
END
